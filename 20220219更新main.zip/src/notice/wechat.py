#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author : EXP
# @Time   : 2020/5/2 14:53
# @File   : wechat.py
# -----------------------------------------------
# 通过 微信公众号 发送威胁情报
# -----------------------------------------------

def to_wechat(cves):
    pass
